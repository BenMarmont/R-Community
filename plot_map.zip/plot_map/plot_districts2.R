
# libraries ####
library(sf)
library(readxl)
library(janitor)
library(dplyr)
library(stringr)
library(ggplot2)
library(ggthemes)

# read district boundaries
district <- read_sf("shapefiles/nz-territorial-authorities-2006-census.shp")
ggplot(district) + geom_sf(aes())
object.size(district) # crashes if too big
st_crs(district)

# read coastline
coastline <- read_sf("shapefiles/dairy-base-regions.shp") %>% st_union()
ggplot(coastline) + geom_sf(aes())
object.size(coastline) # crashes if too big
st_crs(coastline)

# mask by coastline 
district <- district %>% 
  st_make_valid() %>% # correct overlaps 
  st_intersection(coastline) %>% 
  st_simplify(preserveTopology = TRUE, dTolerance = 1000) %>% # make smaller
  clean_names()
ggplot(coastline) + geom_sf(aes())
object.size(district) # crashes if too big

# standardise district names
tldata <- read_excel("List of TLAs against Dairy Statistics and Economic Survey Regions v3 MN.xlsx") %>% clean_names() 
district <- district %>%
  mutate(
    ta_no = as.numeric(ta_no), # different numbering system
    dbdistrict = tldata$dairy_base_district_number[match(ta_name, tldata$tla_2020)],
    dbdistrict = case_when( # fill in gaps using ta_no
      ta_no >= 4 & ta_no <= 10 ~ ta_no, # Auckland
      ta_no == 37 ~ 33, # Whanganui
      TRUE ~ dbdistrict)
  ) %>% 
  dplyr::select(-ta_no) # drop this to avoid mistakes later

# get herds by district 
dsdata <- read.csv("dsdata.csv")
temp <- dsdata %>% 
  dplyr::filter(year_beginning >= 2011, year_beginning <= 2020) %>% # choose recent years
  group_by(dbdistrict, dbdistrict2) %>% 
  summarise(
    mindist = as.numeric(str_extract(dbdistrict[1], "^[0-9]+")),
    maxdist = as.numeric(str_extract(dbdistrict[1], "[0-9]+$")),
    meanherdsperyear = mean(total_herds) # by dbdistrict
  ) %>% 
  ungroup() %>% 
  arrange(mindist)
temp2 <- district %>% 
  cbind(st_coordinates(st_centroid(district))) %>% 
  group_by(dbdistrict) %>% # totals for each group
  mutate(
    mindist = sum(temp$mindist * (dbdistrict >= temp$mindist) * (dbdistrict <= temp$maxdist)),
    maxdist = sum(temp$maxdist * (dbdistrict >= temp$mindist) * (dbdistrict <= temp$maxdist)),
    meanherdsperyear = sum(temp$meanherdsperyear * (dbdistrict >= temp$mindist) * (dbdistrict <= temp$maxdist)),
  ) %>% 
  group_by(mindist, maxdist) %>% # centroid for each group
  mutate(
    X2 = mean(X),
    Y2 = mean(Y),
    n0 = mean(meanherdsperyear),
    label = ifelse(n0 == "0", "", as.character(round(n0))),
    bin = 50,
    dbin = 1,
    cap = ceiling(n0/bin)*bin,
    n = case_when(
      n0 == 0 ~ "  0",
      n0 > 7 * bin ~ str_c(7 * bin + dbin, "+"),
      TRUE ~ str_c(format(cap - bin + dbin, width = 3), "-", format(cap, width = 3))),
  ) %>% 
  ungroup()
temp2 %>% 
  ggplot() +
  labs(title = "DairyStats Herd Locations 2011-2020", fill = "N Herds", x = "", y = "") +
  geom_sf(aes(fill = n), alpha = 0.6) +
  geom_text(aes(X2, Y2, label = label), size = 3, colour = "black") +
  scale_fill_brewer(palette = "YlOrBr")

